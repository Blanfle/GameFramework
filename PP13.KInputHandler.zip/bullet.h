#pragma once
#include "SDLGameObject.h"
#include "InputHandler.h"
#include <vector>

class Bullet : public SDLGameObject
{
private:
	void handleInput();
	std::vector<GameObject*> m_gameObjects;

public:
	Bullet(const LoaderParams* pParams);
	virtual void draw();
	virtual void update();
	virtual void clean();
};
