#pragma once
#include "Bullet.h"

Bullet::Bullet(const LoaderParams* pParams) : SDLGameObject(pParams)
{
}
void Bullet::draw()
{
	SDLGameObject::draw();
}
void Bullet::update()
{
	handleInput();
	m_acceleration.setX(1);
	if (m_position.getX() == 500)
	{
		m_gameObjects.pop_back();
	}
}
void Bullet::clean()
{
}
void Bullet::handleInput()
{
	if (TheInputHandler::Instance()->isKeyDown(SDL_SCANCODE_LCTRL))
	{
		m_gameObjects.push_back(new Bullet(new LoaderParams(100, 100, 128, 82, "animate1")));
		m_currentFrame = int(((SDL_GetTicks() / 100) % 1));
		SDLGameObject::update();
		
	}
}